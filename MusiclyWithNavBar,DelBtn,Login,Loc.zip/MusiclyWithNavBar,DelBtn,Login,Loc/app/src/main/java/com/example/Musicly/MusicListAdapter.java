package com.example.Musicly;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import androidx.recyclerview.widget.RecyclerView;

public class MusicListAdapter extends RecyclerView.Adapter<MusicListAdapter.ViewHolder> {

    private ArrayList<AudioModel> songsList;
    private Context context;
    private List<Integer> selectedPositions; // Added to keep track of selected positions
    private MediaPlayer mediaPlayer;
    private int lastPlayedPosition = -1;
    private boolean[] isPlaying;

    public MusicListAdapter(ArrayList<AudioModel> songsList, Context context) {
        this.songsList = songsList;
        this.context = context;
        this.selectedPositions = new ArrayList<>(); // Initialize the selected positions list
        this.mediaPlayer = MyMediaPlayer.getInstance();
        this.isPlaying = new boolean[songsList.size()]; // Initialize the playing state array
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.recycler_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        AudioModel songData = songsList.get(position);
        holder.titleTextView.setText(songData.getTitle());

        // Set the text color based on the selected position
        if (selectedPositions.contains(position)) {
            holder.titleTextView.setTextColor(Color.parseColor("#FF0000"));
        } else {
            holder.titleTextView.setTextColor(Color.parseColor("#000000"));
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Toggle the selection of the position
                if (selectedPositions.contains(position)) {
                    selectedPositions.remove(Integer.valueOf(position));
                } else {
                    selectedPositions.add(position);
                }

                // Update the UI
                notifyDataSetChanged();
            }
        });

        holder.iconImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the item at the current position
                AudioModel song = getItem(position);

                // Stop the MediaPlayer if the song being played is deleted
                if (lastPlayedPosition == position) {
                    stopMediaPlayer();
                    isPlaying[position] = false;
                }

                // Perform the delete operation for the item
                deleteSong(position);

                // Update the UI
                notifyDataSetChanged();
            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                // Play or stop the song
                if (lastPlayedPosition == position) {
                    if (isPlaying[position]) {
                        pauseMediaPlayer();
                        isPlaying[position] = false;
                    } else {
                        resumeMediaPlayer();
                        isPlaying[position] = true;
                    }
                } else {
                    playSong(position);
                    isPlaying[position] = true;
                }
                return true;
            }
        });
    }

    @Override
    public int getItemCount() {
        return songsList.size();
    }

    public AudioModel getItem(int position) {
        return songsList.get(position);
    }

    public List<Integer> getSelectedPositions() {
        return selectedPositions;
    }

    public void removeSelectedItems() {
        // Create a temporary list to hold the items to be deleted
        ArrayList<AudioModel> itemsToRemove = new ArrayList<>();

        // Iterate through the selected positions and add the corresponding items to the temporary list
        for (int position : selectedPositions) {
            itemsToRemove.add(songsList.get(position));
        }

        // Stop the MediaPlayer if the last played song is deleted
        if (lastPlayedPosition >= 0 && selectedPositions.contains(lastPlayedPosition)) {
            stopMediaPlayer();
            lastPlayedPosition = -1;
        }

        // Remove the items from the main songsList
        songsList.removeAll(itemsToRemove);

        // Clear the selected positions list
        selectedPositions.clear();

        // Update the UI
        notifyDataSetChanged();
    }

    public void clearSelectedPositions() {
        selectedPositions.clear();
    }

    private void playSong(int position) {
        stopMediaPlayer();

        try {
            AudioModel song = songsList.get(position);
            mediaPlayer.setDataSource(song.getPath());
            mediaPlayer.prepare();
            mediaPlayer.start();
            lastPlayedPosition = position;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void pauseMediaPlayer() {
        if (mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
        }
        isPlaying[lastPlayedPosition] = false;
    }

    private void resumeMediaPlayer() {
        if (!mediaPlayer.isPlaying()) {
            mediaPlayer.start();
        }
        isPlaying[lastPlayedPosition] = true;
    }

    private void stopMediaPlayer() {
        if (mediaPlayer.isPlaying()) {
            mediaPlayer.stop();
        }
        mediaPlayer.reset();
    }

    private void deleteSong(int position) {
        // Remove the song from the list
        songsList.remove(position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView titleTextView;
        ImageView iconImageView;

        public ViewHolder(View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.music_title_text);
            iconImageView = itemView.findViewById(R.id.icon_view);
        }
    }
}
