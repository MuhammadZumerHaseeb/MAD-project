package com.example.Musicly;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

import java.io.File;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    DrawerLayout drawerlayout;
    NavigationView navigationview;
    ActionBarDrawerToggle drawerToggle;
    RecyclerView recyclerView;
    TextView noMusicTextView;
    Button deleteButton;
    MusicListAdapter adapter;

    ArrayList<AudioModel> songsList = new ArrayList<>();

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (drawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        drawerlayout = findViewById(R.id.drawer_layout);
        navigationview = findViewById(R.id.nav_view);

        drawerToggle = new ActionBarDrawerToggle(this, drawerlayout, R.string.open, R.string.close);
        drawerlayout.addDrawerListener(drawerToggle);
        drawerToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        navigationview.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @SuppressLint("NonConstantResourceId")
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                switch (item.getItemId()) {
                    case R.id.login: {
                        Toast.makeText(MainActivity.this, "Login Selected", Toast.LENGTH_SHORT).show();
                        Intent i = new Intent(MainActivity.this, LoginPage.class);
                        startActivity(i);
                        break;
                    }
                    case R.id.location: {
                        Toast.makeText(MainActivity.this, "Location Selected", Toast.LENGTH_SHORT).show();
                        Intent i = new Intent(MainActivity.this, Map.class);
                        startActivity(i);
                        break;
                    }
                    case R.id.CheckUpdate: {
                        Toast.makeText(MainActivity.this, "You are already using the latest version", Toast.LENGTH_SHORT).show();
                        break;
                    }
                    case R.id.aboutme: {
                        Toast.makeText(MainActivity.this, "About Me Selected", Toast.LENGTH_SHORT).show();
                        Intent i = new Intent(MainActivity.this, AboutMe.class);
                        startActivity(i);
                        break;
                    }
                    case R.id.rating: {
                        Toast.makeText(MainActivity.this, "Thanks For Rating !!!", Toast.LENGTH_SHORT).show();
                        break;
                    }
                }

                return false;
            }
        });

        recyclerView = findViewById(R.id.recycler_view);
        noMusicTextView = findViewById(R.id.no_songs_text);
        deleteButton = findViewById(R.id.deleteButton);

        if (checkPermission() == false) {
            requestPermission();
            return;
        }

        String[] projection = {
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.DATA,
                MediaStore.Audio.Media.DURATION
        };

        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";

        Cursor cursor = getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, projection, selection, null, null);
        while (cursor.moveToNext()) {
            AudioModel songData = new AudioModel(cursor.getString(1), cursor.getString(0), cursor.getString(2));
            if (new File(songData.getPath()).exists())
                songsList.add(songData);
        }

        if (songsList.size() == 0) {
            noMusicTextView.setVisibility(View.VISIBLE);
        } else {
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            adapter = new MusicListAdapter(songsList, getApplicationContext());
            recyclerView.setAdapter(adapter);
        }

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                adapter.removeSelectedItems();

                // Check if the songsList is empty and show/hide the noMusicTextView accordingly
                if (songsList.size() == 0) {
                    noMusicTextView.setVisibility(View.VISIBLE);
                } else {
                    noMusicTextView.setVisibility(View.GONE);
                }
            }
        });
    }

    private boolean checkPermission() {
        int READ_EXTERNAL_STORAGE_PERMISSION = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE);
        return READ_EXTERNAL_STORAGE_PERMISSION == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                recreate();
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
